/**
 * Minesweeper.java
 * 
 * This program creates a Minesweeper game board of size m×n with k mines
 * placed randomly. Each non-mine cell displays the number of adjacent mines.
 */
public class Minesweeper {

    public static void main(String[] args) {
        // Parse command-line arguments
        int m = Integer.parseInt(args[0]); // Number of rows
        int n = Integer.parseInt(args[1]); // Number of columns
        int k = Integer.parseInt(args[2]); // Number of mines

        // Create the mine field
        boolean[][] hasMineArr = new boolean[m][n];

        // Place k mines randomly on the board
        int remainingMines = k;
        while (remainingMines > 0) {
            int x = (int) (Math.random() * m);
            int y = (int) (Math.random() * n);

            // Only place a mine if the position doesn't already have one
            if (!hasMineArr[x][y]) {
                hasMineArr[x][y] = true;
                remainingMines--;
            }
        }

        // Calculate number of adjacent mines for each cell
        int[][] neighboringMineArr = new int[m][n];
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                // Skip calculation for cells with mines
                if (hasMineArr[i][j]) {
                    continue;
                }

                // Count mines in all 8 adjacent cells
                int mineCount = 0;

                // Check all 8 surrounding positions
                for (int di = -1; di <= 1; di++) {
                    for (int dj = -1; dj <= 1; dj++) {
                        // Skip the current cell
                        if (di == 0 && dj == 0) {
                            continue;
                        }

                        // Calculate adjacent position
                        int ni = i + di;
                        int nj = j + dj;

                        // Check if position is valid and has a mine
                        if (ni >= 0 && ni < m && nj >= 0 && nj < n && hasMineArr[ni][nj]) {
                            mineCount++;
                        }
                    }
                }

                neighboringMineArr[i][j] = mineCount;
            }
        }

        // Display the Minesweeper board
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                if (hasMineArr[i][j]) {
                    System.out.print("*  "); // Display mines as asterisks
                } else {
                    System.out.print(neighboringMineArr[i][j] + "  "); // Display count of adjacent mines
                }
            }
            System.out.println(); // End each row with a newline
        }
    }
}
