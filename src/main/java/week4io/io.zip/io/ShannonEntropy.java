/**
 * Shannon Entropy Calculator
 * 
 * This program calculates the Shannon entropy of a sequence of integers.
 * Shannon entropy is a measure of information content and randomness in a data
 * source.
 * 
 * Formula: H = -Σ(pi * log2(pi)) where:
 * - pi is the proportion of integers with value i
 * - If pi = 0, then pi*log2(pi) = 0
 * 
 * Usage: java -cp .:stdlib.jar ShannonEntropy m < input.txt
 * - m: upper bound for integer values (values must be between 1 and m)
 * - input.txt: file containing sequence of integers
 */
public class ShannonEntropy {

    public static void main(String[] args) {

        // take a command-line integer m
        int m = Integer.parseInt(args[0]);

        // Step 1: Count frequency of each integer in the range [1,m]
        int[] frequencies = new int[m];

        int totalCount = 0; // Track total number of integers read
        // Read integers from standard input
        while (!StdIn.isEmpty()) {
            int value = StdIn.readInt();
            frequencies[value - 1] += 1; // -1 to adjust for 0-based array indexing
            totalCount++;
        }

        // Step 2: Calculate Shannon entropy using the formula H = -Σ(pi * log2(pi))
        double shannonEntropy = 0.0;

        for (int i = 0; i < m; i++) {
            // Calculate proportion (pi) for each value
            double proportion = ((double) frequencies[i]) / totalCount;

            // Note: When pi = 0, the term pi*log2(pi) = 0 (by convention in information
            // theory)
            if (proportion > 0) {
                // Convert natural log to base-2 log: log2(x) = ln(x)/ln(2)
                shannonEntropy += -(proportion * Math.log(proportion) / Math.log(2));
            }
        }

        // Print the Shannon entropy with exactly 4 decimal places
        StdOut.printf("%.4f\n", shannonEntropy);
    }
}
