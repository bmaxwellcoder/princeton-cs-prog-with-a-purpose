public class ActivationFunction {
    // Returns the Heaviside function of x.
    // Note: No direct equivalent in Java Math library
    public static double heaviside(double x) {
        if (Double.isNaN(x)) {
            return Double.NaN;
        }

        // Handle infinity and maximum values
//        if (x == Double.POSITIVE_INFINITY || x == Double.MAX_VALUE) {
//            return 1.0;
//        }
//        if (x == Double.NEGATIVE_INFINITY || x == -Double.MAX_VALUE) {
//            return 0.0;
//        }

        if (x == Double.POSITIVE_INFINITY) {
            return 1.0;
        }
        if (x == Double.NEGATIVE_INFINITY) {
            return 0.0;
        }

        if (x < 0) {
            return 0.0;
        } else if (x == 0) {
            return 0.5;
        } else {
            return 1;
        }
    }

    // Returns the sigmoid function of x.
    // Note: No direct equivalent in Java Math library
    public static double sigmoid(double x) {
        if (Double.isNaN(x)) {
            return Double.NaN;
        }

        // Handle infinity and maximum values
//        if (x == Double.POSITIVE_INFINITY || x == Double.MAX_VALUE) {
//            return 1.0;
//        }
//        if (x == Double.NEGATIVE_INFINITY || x == -Double.MAX_VALUE) {
//            return 0.0;
//        }

        if (x == Double.POSITIVE_INFINITY) {
            return 1.0;
        }
        if (x == Double.NEGATIVE_INFINITY) {
            return 0.0;
        }

        // For very small values, sigmoid(x) ≈ 0.5 + x/4
        if (Math.abs(x) < Double.MIN_NORMAL) {
            return 0.5 + x / 4;
        }

        return 1 / (1 + Math.pow(Math.E, -x));
    }

    // Returns the hyperbolic tangent of x.
    // Note: Equivalent to Math.tanh(x)
    public static double tanh(double x) {
        if (Double.isNaN(x)) {
            return Double.NaN;
        }

        // Handle special cases
        if (x == Double.POSITIVE_INFINITY || x == Double.MAX_VALUE) {
            return 1.0;
        }
        if (x == Double.NEGATIVE_INFINITY || x == -Double.MAX_VALUE) {
            return -1.0;
        }


        // For very small values, tanh(x) ≈ x
        if (Math.abs(x) < Double.MIN_NORMAL) {
            return x;
        }

        // Regular calculation for normal values
        return (Math.pow(Math.E, x) - Math.pow(Math.E, -x))
                / (Math.pow(Math.E, x) + Math.pow(Math.E, -x));
    }

    // Returns the softsign function of x.
    // Note: No direct equivalent in Java Math library
    public static double softsign(double x) {
        if (Double.isNaN(x)) {
            return Double.NaN;
        }

        // Handle infinity and maximum values
//        if (x == Double.POSITIVE_INFINITY || x == Double.MAX_VALUE) {
//            return 1.0;
//        }
//        if (x == Double.NEGATIVE_INFINITY || x == -Double.MAX_VALUE) {
//            return -1.0;
//        }
        if (x == Double.POSITIVE_INFINITY) {
            return 1.0;
        }
        if (x == Double.NEGATIVE_INFINITY) {
            return -1.0;
        }

        // For very small values, softsign(x) ≈ x
        if (Math.abs(x) < Double.MIN_NORMAL) {
            return x;
        }

        return x / (1 + Math.abs(x));
    }

    // Returns the square nonlinearity function of x.
    // Note: No direct equivalent in Java Math library
    public static double sqnl(double x) {
        if (Double.isNaN(x)) {
            return Double.NaN;
        }

        // Handle infinity and maximum values
//        if (x == Double.POSITIVE_INFINITY || x == Double.MAX_VALUE) {
//            return 1.0;
//        }
//        if (x == Double.NEGATIVE_INFINITY || x == -Double.MAX_VALUE) {
//            return -1.0;
//        }
        if (x == Double.POSITIVE_INFINITY) {
            return 1.0;
        }
        if (x == Double.NEGATIVE_INFINITY) {
            return -1.0;
        }

        // For very small values, sqnl(x) ≈ x
        if (Math.abs(x) < Double.MIN_NORMAL) {
            return x;
        }

        if (x <= -2) {
            return -1;
        } else if ((x > -2) && (x < 0)) {
            return x + (Math.pow(x, 2) / 4);
        } else if ((x >= 0) && (x < 2)) {
            return x - (Math.pow(x, 2) / 4);
        } else {
            return 1;
        }
    }

    // Takes a double command-line argument x and prints each activation
    // function, evaluated, in the format (and order) given below.
    public static void main(String[] args) {

        double x = Double.parseDouble(args[0]);
        System.out.println("heaviside(" + x + ") = " + heaviside(x));
        System.out.println("sigmoid(" + x + ") = " + sigmoid(x));
        System.out.println("tanh(" + x + ") = " + tanh(x));
        System.out.println("softsign(" + x + ") = " + softsign(x));
        System.out.println("sqnl(" + x + ") = " + sqnl(x));
    }
}
