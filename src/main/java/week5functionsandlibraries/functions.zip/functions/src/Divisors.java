public class Divisors {
    /**
     * Returns the greatest common divisor of a and b.
     * Uses the Euclidean algorithm by finding the largest number that divides both
     * a and b.
     *
     * @param a the first number
     * @param b the second number
     * @return the greatest common divisor of a and b
     */
    public static int gcd(int a, int b) {
        // Handle special cases
        if (a == 0 && b == 0) {
            return 0;
        } else if (b == 0) {
            return Math.abs(a);
        }

        // Work with absolute values
        int absA = Math.abs(a);
        int absB = Math.abs(b);

        // Use Euclidean algorithm
        while (absA % absB != 0) {
            int temp = absA;
            absA = absB;
            absB = temp % absB;
        }

        return absB;
    }

    // Returns the least common multiple of a and b.
    // Uses the relationship: lcm(a,b) = |a*b| / gcd(a,b)
    public static int lcm(int a, int b) {
        // Approach # 1
        if (a == 0 || b == 0) {
            return 0;
        }

        int aPositive = Math.abs(a);
        int bPositive = Math.abs(b);

        return (aPositive / gcd(a, b)) * bPositive;

        // Approach #2
        // // Handle special case where either number is 0
        // if (a == 0 || b == 0) {
        // return 0;
        // }
        //
        // // Work with absolute values
        // int absA = Math.abs(a);
        // int absB = Math.abs(b);
        //
        // // If numbers are equal, either one is the LCM
        // if (absA == absB) {
        // return absA;
        // }
        //
        // // Find the smaller and larger number
        // int smaller = Math.min(absA, absB);
        // int larger = Math.max(absA, absB);
        //
        // // Generate multiples of the larger number up to the smaller number
        // int[] largerMultiples = new int[smaller];
        // for (int i = 0; i < smaller; i++) {
        // largerMultiples[i] = larger * (i + 1);
        // }
        //
        // // Check each multiple of the larger number
        // for (int i = 0; i < largerMultiples.length; i++) {
        // int multiple = largerMultiples[i];
        // // For each multiple, check if it's also a multiple of the smaller number
        // for (int j = 1; j <= smaller; j++) {
        // int smallerMultiple = smaller * j;
        //
        // // If we've gone past the current multiple, move to next one
        // if (smallerMultiple > multiple) {
        // break;
        // }
        //
        // // If we find a match, we've found the LCM
        // if (multiple == smallerMultiple) {
        // return multiple;
        // }
        // }
        // }
        //
        // // If no common multiple found, the LCM is the product
        // return absA * absB;
    }

    // Returns true if a and b are relatively prime; false otherwise.
    // Two numbers are relatively prime if their GCD is 1.
    public static boolean areRelativelyPrime(int a, int b) {
        return gcd(a, b) == 1;
    }

    // Returns the number of integers between 1 and n that are
    // relatively prime with n (Euler's totient function).
    // For example, totient(9) = 6 because 1,2,4,5,7,8 are relatively prime with 9.
    public static int totient(int n) {
        // Handle non-positive input
        if (n <= 0) {
            return 0;
        }

        // Count numbers that are relatively prime with n
        int primeCount = 0;
        for (int i = 0; i < n; i++) {
            if (areRelativelyPrime(n, (i + 1))) {
                primeCount++;
            }
        }

        return primeCount;
    }

    // Takes two integer command-line arguments a and b and prints
    // each function, evaluated in the format (and order) given below.
    public static void main(String[] args) {
        int a = Integer.parseInt(args[0]);
        int b = Integer.parseInt(args[1]);

        System.out.println("gcd(" + a + ", " + b + ") = " + gcd(a, b));
        System.out.println("lcm(" + a + ", " + b + ") = " + lcm(a, b));
        System.out.println("areRelativelyPrime(" + a + ", " + b + ") = "
                + areRelativelyPrime(a, b));
        System.out.println("totient(" + a + ") = " + totient(a));
        System.out.println("totient(" + b + ") = " + totient(b));
    }
}
