/**
 * TrinomialBrute.java
 * Computes trinomial coefficients using a recursive brute-force approach.
 * The trinomial coefficient T(n, k) is the coefficient of x^(n+k) in the
 * expansion of (1 + x + x^2)^n.
 * 
 * This implementation uses a simple recursive approach which is inefficient for
 * large values of n and k
 * due to redundant calculations. For better performance, see TrinomialDP.java.
 */
public class TrinomialBrute {

    /**
     * Computes the trinomial coefficient T(n, k) using recursion.
     * 
     * The trinomial coefficient T(n, k) represents the coefficient of x^k in the
     * expansion of (1 + x + x^2)^n.
     * 
     * Recurrence relation:
     * - T(0,0) = 1
     * - T(n,k) = 0 if k < -n or k > n
     * - T(n,k) = T(n-1,k-1) + T(n-1,k) + T(n-1,k+1) otherwise
     * 
     * @param n the power in the expansion
     * @param k the coefficient index
     * @return the trinomial coefficient T(n, k)
     */
    public static long trinomial(int n, int k) {
        // Base case: T(0,0) = 1
        if (n == 0 && k == 0) {
            return 1;
        }

        // Base case: T(n,k) = 0 if k is outside valid range
        if (k < -n || k > n) {
            return 0;
        }

        // Recursive case: T(n,k) = T(n-1,k-1) + T(n-1,k) + T(n-1,k+1)
        return trinomial(n - 1, k - 1) + trinomial(n - 1, k) + trinomial(n - 1, k + 1);
    }

    /**
     * Takes two integer command-line arguments n and k and prints T(n, k).
     * 
     * @param args command-line arguments [n k]
     */
    public static void main(String[] args) {
        int n = Integer.parseInt(args[0]);
        int k = Integer.parseInt(args[1]);
        System.out.println(trinomial(n, k));
    }
}
