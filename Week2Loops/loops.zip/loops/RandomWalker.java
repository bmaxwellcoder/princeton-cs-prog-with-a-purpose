public class RandomWalker {

    public static void main(String[] args) {

        int r = Integer.parseInt(args[0]);

        int x = 0;
        int y = 0;
        int stepCount = 0;
        System.out.println("(" + x + "," + y + ")");
        while(Math.abs(x) + Math.abs(y) != r) {
            double randomVal = Math.random();
            if (randomVal < 0.25) {
                x++;
                stepCount++;
            } else if (randomVal >= 0.25 && randomVal < 0.5) {
                x--;
                stepCount++;
            } else if (randomVal >= 0.5 && randomVal < 0.75) {
                y++;
                stepCount++;
            } else {
                y--;
                stepCount++;
            }

            System.out.println("(" + x + ", " + y + ")");
        }

        System.out.println("steps = " + stepCount);
    }
}
