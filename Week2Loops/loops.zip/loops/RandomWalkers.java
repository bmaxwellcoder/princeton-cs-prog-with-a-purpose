public class RandomWalkers {

    public static void main(String[] args) {

        int r = Integer.parseInt(args[0]);
        int trials = Integer.parseInt(args[1]);

        int totalStepsOfTrials = 0;

        for (int i = 0; i < trials; i++) {
            int x = 0;
            int y = 0;
            while (Math.abs(x) + Math.abs(y) != r) {
                double randomVal = Math.random();
                if (randomVal < 0.25) {
                    x++;
                    totalStepsOfTrials++;
                } else if (randomVal >= 0.25 && randomVal < 0.5) {
                    x--;
                    totalStepsOfTrials++;
                } else if (randomVal >= 0.5 && randomVal < 0.75) {
                    y++;
                    totalStepsOfTrials++;
                } else {
                    y--;
                    totalStepsOfTrials++;
                }
            }
        }

        double averageNumSteps = (double) totalStepsOfTrials / (double) trials;
        System.out.println("average number of steps = " + averageNumSteps);
    }
}
